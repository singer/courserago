package main

func main() {
	println("run as\n\ngo test -v -race")
}
